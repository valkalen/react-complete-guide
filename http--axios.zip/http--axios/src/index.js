import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import axios from 'axios';


axios.defaults.baseURL = 'https://jsonplaceholder.typicode.com';
axios.defaults.headers.common['Authorization'] = 'AUTH TOKEN';
axios.defaults.headers.post['Content-Type'] = 'application/json'; //it is default , no need to do it. it is here as an example

//the interceptors are used usually to add token authorization or some modification
//it will effect all of the request sent by any component in the project. The reason why is it is placed in the most global file index.js
axios.interceptors.request.use(request => {
    console.log(request);
    //Edit request config
    return request; //always need to return it, otherwise you will stop all requests. You can modify the request though.
}, error => {
    //handle error globally
    console.log(error);
    //this promise will still pass the error down to the page that initiated the get call
    return Promise.reject(error); 
});

axios.interceptors.response.use(response => {
    console.log(response);
    //Edit response config
    return response; 
}, error => {
    //handle error globally
    console.log(error);
    return Promise.reject(error); 
});

//if you want to bypass interceptor, then do this:
// const myInterceptor = axios.interceptors.request.use(function () {/*...*/});
// axios.interceptors.request.eject(myInterceptor);
// myInterceptor should be accessed globally
ReactDOM.render( <App />, document.getElementById( 'root' ) );
registerServiceWorker();
