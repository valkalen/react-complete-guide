import  axios from 'axios';

//you can create multiple instances
//instances will only overwrite the default settings set in index.js that are also set in the instance. All other defaults will be kept.
const instance = axios.create({
    baseURL: 'https://jsonplaceholder.typicode.com'
});

instance.defaults.headers.common['Authorization'] = 'AUTH TOKEN FROM INSTANCE';
// instance.intercetpors.request...
// instance.interceptors.response...
export default instance;